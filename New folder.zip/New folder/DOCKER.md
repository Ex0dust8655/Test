# Docker Setup & HTTP URL (ChatGPT Debug Mode)

## Quick start

From the project root (Linux/macOS or Git Bash/WSL on Windows):

```bash
chmod +x setup.sh
./setup.sh
```

On Windows (PowerShell) you can run the Docker commands from [Manual run (HTTP)](#manual-run-http) below instead of `setup.sh`.

The script will:

1. Build the Docker image (Python, Go, Gobuster, Nuclei, app).
2. Ask: **Host the MCP server over HTTP for URL access?**
   - **Yes** → Runs the server with HTTP/SSE on port 8000 (or a port you choose). You get a URL to use with ChatGPT or MCP Inspector.
   - **No** → Prints how to run the container for Cursor (stdio).

---

## Host over HTTP (for ChatGPT / debug mode)

If you chose **Yes** in `setup.sh`, the server listens on `0.0.0.0:8000` (or your port).

- **SSE endpoint:** `http://localhost:8000/sse`
- **Messages:** `http://localhost:8000/messages/`

### Connect ChatGPT (debug mode)

1. Use an MCP client or Inspector that supports connecting via URL.
2. **MCP Inspector (browser):**  
   - Open [inspector.mcp-use.com](https://inspector.mcp-use.com) or run:
   - `npx @mcp-use/inspector --url http://localhost:8000/sse`
3. **ChatGPT / custom client:**  
   Point the MCP client at:
   - **URL:** `http://localhost:8000/sse`  
   (Use `http://<your-machine-ip>:8000/sse` if the client is on another machine.)

Debug mode typically means connecting a client to this URL so you can call tools (list_wordlists, run_gobuster, run_nuclei) over HTTP.

### Manual run (HTTP)

```bash
docker build -t security-scan-mcp .
docker run -d --name security-scan-mcp -p 8000:8000 \
  -v "$(pwd)/SecLists:/app/SecLists:ro" \
  security-scan-mcp \
  python -m mcp_server.server --transport sse --port 8000 --host 0.0.0.0
```

- **Logs:** `docker logs -f security-scan-mcp`
- **Stop:** `docker stop security-scan-mcp`

---

## Run without HTTP (stdio for Cursor)

For Cursor, run the server in stdio mode (no URL). In Cursor MCP config, use:

**Command:** `docker`  
**Args:** `run`, `-i`, `--rm`, `-v`, `C:\New folder\SecLists:/app/SecLists:ro`, `security-scan-mcp`

(Replace `C:\New folder` with your project path; on macOS/Linux use the path to your project.)

---

## SecLists in Docker

- **Build-time (optional):**  
  `docker build --build-arg CLONE_SECLISTS=true -t security-scan-mcp .`  
  (Larger image; wordlists baked in.)

- **Runtime (recommended):**  
  Clone SecLists on the host and mount:
  - `-v /path/to/SecLists:/app/SecLists:ro`  
  `setup.sh` uses `$PROJECT_ROOT/SecLists` if present.

---

## Environment variables

| Variable        | Description                          |
|----------------|--------------------------------------|
| `SECLISTS_PATH` | Path to SecLists in container (default `/app/SecLists`) |
| `PORT`         | Host port when using HTTP (default `8000`) |
| `IMAGE_NAME`   | Docker image name (default `security-scan-mcp`) |
| `CONTAINER_NAME` | Container name (default `security-scan-mcp`) |

Example:

```bash
PORT=9000 ./setup.sh
```

Then connect to `http://localhost:9000/sse`.
