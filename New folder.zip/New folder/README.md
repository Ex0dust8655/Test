# Security Scan MCP Server + LangGraph Agent

Autonomous security scanning tool with:

- **MCP Server**: Exposes **Nuclei**, **Gobuster**, and **SecLists** wordlists as tools so you can use them from **Cursor** or any MCP client (e.g. ChatGPT with MCP).
- **LangGraph Agent**: Agentic workflow that runs Gobuster → asks for status codes → asks whether to run Nuclei → runs Nuclei if requested. Use from CLI or drive from an LLM.

**→ Step-by-step run on your system (including SecLists): see [SETUP.md](SETUP.md).**  
**→ Docker + HTTP URL (ChatGPT debug mode): see [DOCKER.md](DOCKER.md) and run [setup.sh](setup.sh).**

## Prerequisites

- **Python 3.10+**
- **Go** (for Gobuster and Nuclei)
- **SecLists** (optional but recommended; [download from GitHub](https://github.com/danielmiessler/SecLists))

## 1. Install System Tools

### Gobuster

```bash
go install github.com/OJ/gobuster/v3@latest
```

Ensure `$GOPATH/bin` (or `$HOME/go/bin`) is in your `PATH`.

### Nuclei

```bash
go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest
nuclei -update-templates
```

### SecLists (wordlists)

```bash
git clone --depth 1 https://github.com/danielmiessler/SecLists.git
```

Set the path (optional; auto-detected in common locations):

- **Linux/macOS**: `export SECLISTS_PATH=/path/to/SecLists`
- **Windows**: `set SECLISTS_PATH=C:\path\to\SecLists`

Auto-detected paths: `/usr/share/seclists`, `C:\SecLists`, `~/SecLists`, `~/tools/SecLists`.

## 2. Install Python Dependencies

From the project root (`c:\New folder` or your clone):

```bash
pip install -r requirements.txt
```

Or with uv:

```bash
uv pip install -r requirements.txt
```

## 3. Configure and Use

### Option A: Use MCP Server from Cursor

1. **Add the MCP server** in Cursor:
   - Open **Cursor Settings** → **MCP** (or `~/.cursor/mcp.json` on macOS/Linux).
   - Add a server entry. Example (adjust paths for your OS):

   **Windows** (`%USERPROFILE%\.cursor\mcp.json`):

   ```json
   {
     "mcpServers": {
       "security-scan": {
         "command": "python",
         "args": ["-m", "mcp_server.server"],
         "cwd": "C:\\New folder",
         "env": {}
       }
     }
   }
   ```

   **macOS/Linux** (`~/.cursor/mcp.json`):

   ```json
   {
     "mcpServers": {
       "security-scan": {
         "command": "python",
         "args": ["-m", "mcp_server.server"],
         "cwd": "/path/to/your/New folder",
         "env": {}
       }
     }
   }
   ```

2. **Restart Cursor** (or reload MCP).

3. **Chat in Cursor**: Ask things like:
   - “List available SecLists wordlists for directory busting.”
   - “Run gobuster on https://example.com with wordlist [path from list_wordlists]. Show status codes 200,301,403.”
   - “Run nuclei on https://example.com.”
   The model will call the MCP tools (`list_wordlists`, `run_gobuster`, `run_nuclei`) and can ask you for status codes or whether to run Nuclei in the conversation.

### Option B: Use MCP Server from ChatGPT (with MCP)

If you use an MCP client that connects ChatGPT to MCP servers, add this server the same way (command: `python`, args: `["-m", "mcp_server.server"]`, cwd: project root). Then you can say “run gobuster on …” and “use wordlist X” / “show status codes 200,301” / “run nuclei” in chat.

### Option C: Run the LangGraph Agent from CLI

Autonomous flow with built-in prompts for status codes and “Run Nuclei?”:

```bash
# From project root
python -m agent.runner "Run gobuster on https://example.com with common.txt"
```

Or interactive:

```bash
python -m agent.runner
# Enter: Run gobuster on https://example.com with common.txt
```

The agent will:

1. Parse URL and wordlist (suggest one from SecLists if not given).
2. **Ask**: “Which HTTP status codes should I display?” (you can type e.g. `200,301,403` or Enter for default).
3. Run Gobuster and print output.
4. **Ask**: “Run Nuclei on https://example.com? (yes/no)”.
5. If you say yes, run Nuclei and print output; otherwise exit.

## MCP Tools Reference

| Tool | Description |
|------|-------------|
| `list_wordlists` | List SecLists Discovery/Web-Content wordlists (path, name, size). |
| `run_gobuster` | Run `gobuster dir` with `url`, `wordlist_path`, optional `status_codes`, `threads`, `timeout_sec`, `extensions`, `out_file`. |
| `run_nuclei` | Run Nuclei with `target` URL, optional `templates`, `severity`, `concurrency`, `out_file`. |

## Where to store wordlists

- **Custom / small wordlists:** Put `.txt` files in **`wordlists/`** inside the project (e.g. `wordlists/common-small.txt`). Checked first, fast.
- **Full SecLists:** Clone [SecLists](https://github.com/danielmiessler/SecLists) into **`SecLists/`** in the project, or set **`SECLISTS_PATH`** to its path.

See **[WORDLISTS.md](WORDLISTS.md)** for details.

## Environment Variables

| Variable | Description |
|----------|-------------|
| `SECLISTS_PATH` | Path to SecLists repo (optional; auto-detected if not set). |
| `SCAN_THREAD_ID` | Thread ID for LangGraph checkpointer (default: `default`). |

## Project Layout

```
.
├── mcp_server/
│   ├── __init__.py
│   ├── server.py      # MCP server (stdio)
│   └── scanner.py     # Gobuster, Nuclei, SecLists helpers
├── agent/
│   ├── __init__.py
│   ├── state.py       # LangGraph state
│   ├── graph.py       # LangGraph workflow (parse → ask status → gobuster → ask nuclei → nuclei/end)
│   └── runner.py      # CLI runner with interrupt/resume
├── requirements.txt
├── pyproject.toml
├── cursor_mcp_config.json   # Example Cursor MCP config
└── README.md
```

## Steps to Configure and Use (Summary)

1. **Install Go** (if not already): [golang.org](https://go.dev/dl/).
2. **Install Gobuster**: `go install github.com/OJ/gobuster/v3@latest`.
3. **Install Nuclei**: `go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest` then `nuclei -update-templates`.
4. **Clone SecLists**: `git clone --depth 1 https://github.com/danielmiessler/SecLists.git` and set `SECLISTS_PATH` if not in a default path.
5. **Python deps**: `pip install -r requirements.txt` (from project root).
6. **Cursor**: Add the MCP server to `~/.cursor/mcp.json` (or Cursor Settings → MCP) with `command`, `args`, and `cwd` as in the README; restart Cursor.
7. **Chat**: In Cursor, ask to list wordlists, run gobuster with a wordlist and status codes, then run nuclei if desired.
8. **CLI agent**: `python -m agent.runner "Run gobuster on https://example.com with common.txt"` and answer the status-code and nuclei prompts.

## Troubleshooting

- **“gobuster not found”**: Install with `go install github.com/OJ/gobuster/v3@latest` and add Go’s `bin` to `PATH`.
- **“nuclei not found”**: Install with `go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest` and run `nuclei -update-templates`.
- **No wordlists**: Clone SecLists and set `SECLISTS_PATH` (or use one of the auto-detected paths).
- **MCP server not listed in Cursor**: Check `cwd` and `args` in `mcp.json`, and that `python -m mcp_server.server` runs in that directory.

## License

Use at your own risk. Only run scans against targets you are authorized to test.
