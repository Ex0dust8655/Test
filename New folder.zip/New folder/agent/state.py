"""State for the security scan LangGraph workflow."""
from typing import Literal, TypedDict


class ScanState(TypedDict, total=False):
    """State for gobuster → (optional) nuclei scan workflow."""

    # From user / LLM
    user_message: str
    url: str
    wordlist_path: str
    status_codes: str
    run_nuclei: bool

    # Results
    wordlist_suggestion: str
    gobuster_stdout: str
    gobuster_stderr: str
    gobuster_code: int
    nuclei_stdout: str
    nuclei_stderr: str
    nuclei_code: int

    # Human-in-the-loop: what we're waiting for
    pending_question: str
    user_response: str

    # Flow control
    next_step: Literal["ask_status_codes", "run_gobuster", "ask_run_nuclei", "run_nuclei", "end", "parse"]
    messages: list
