"""
CLI runner for the security scan LangGraph agent.
Handles interrupt/resume: when the graph interrupts for status codes or nuclei yes/no,
prompts the user and resumes with Command(resume=...).
"""
import os
import sys

from langgraph.types import Command

from agent.graph import get_graph


def main():
    graph = get_graph()
    thread_id = os.environ.get("SCAN_THREAD_ID", "default")
    config = {"configurable": {"thread_id": thread_id}}

    # Initial input: user message from args or stdin
    if len(sys.argv) > 1:
        user_message = " ".join(sys.argv[1:])
    else:
        print("Enter your request (e.g. 'Run gobuster on https://example.com with common.txt'):")
        user_message = (sys.stdin.readline() or "").strip()
    if not user_message:
        print("No input. Example: Run gobuster on https://example.com with common.txt")
        sys.exit(1)

    initial_input: dict | Command = {"user_message": user_message}

    while True:
        interrupt_prompt = None
        for event in graph.stream(initial_input, config=config, stream_mode="updates"):
            for node_name, node_output in event.items():
                if node_name == "__interrupt__":
                    for item in node_output:
                        if hasattr(item, "value"):
                            interrupt_prompt = item.value
                            break
                    break
                if isinstance(node_output, dict):
                    if "wordlist_suggestion" in node_output:
                        print(node_output["wordlist_suggestion"])
                    if "gobuster_stdout" in node_output and node_output["gobuster_stdout"]:
                        print("--- Gobuster output ---")
                        print(node_output["gobuster_stdout"])
                    if node_output.get("gobuster_stderr"):
                        print("Gobuster stderr:", node_output["gobuster_stderr"], file=sys.stderr)
                    if "nuclei_stdout" in node_output and node_output["nuclei_stdout"]:
                        print("--- Nuclei output ---")
                        print(node_output["nuclei_stdout"])
                    if node_output.get("nuclei_stderr"):
                        print("Nuclei stderr:", node_output["nuclei_stderr"], file=sys.stderr)

        if interrupt_prompt is not None:
            print(interrupt_prompt)
            try:
                user_input = (sys.stdin.readline() or "").strip()
            except (EOFError, KeyboardInterrupt):
                user_input = ""
            initial_input = Command(resume=user_input)
            continue
        break

    print("Done.")


if __name__ == "__main__":
    main()
