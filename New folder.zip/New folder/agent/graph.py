"""
LangGraph workflow: parse user intent → ask status codes (interrupt) → run gobuster → ask run nuclei (interrupt) → run nuclei or end.
"""
import os
import re
import sys
from pathlib import Path

# Add project root for mcp_server import
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import END, START, StateGraph
from langgraph.types import Command, interrupt

from agent.state import ScanState
from mcp_server.scanner import get_seclists_path, list_wordlists, run_gobuster, run_nuclei


def parse_input(state: ScanState) -> ScanState:
    """Extract URL and wordlist from user message; suggest wordlist if not provided."""
    msg = (state.get("user_message") or "").strip()
    url = state.get("url") or ""
    wordlist_path = state.get("wordlist_path") or ""

    # Simple extraction: look for URL and optional wordlist path/name
    url_match = re.search(
        r"https?://[^\s\"']+",
        msg,
        re.IGNORECASE,
    )
    if url_match:
        url = url_match.group(0).rstrip("/") + "/"

    # Wordlist: "wordlist X", "use X", "with X.txt", or path-like
    wl_match = re.search(
        r"(?:wordlist|use|with)\s+([^\s,]+\.txt|[^\s,]+)",
        msg,
        re.IGNORECASE,
    )
    if wl_match:
        candidate = wl_match.group(1).strip()
        if os.path.isabs(candidate) or os.path.isfile(candidate):
            wordlist_path = candidate
        else:
            # Resolve from SecLists
            seclists = get_seclists_path()
            if seclists:
                base = seclists / "Discovery" / "Web-Content"
                if base.is_dir():
                    for f in base.iterdir():
                        if f.is_file() and candidate.lower() in f.name.lower():
                            wordlist_path = str(f)
                            break

    if not wordlist_path:
        # Fast path: use bundled wordlist first (no filesystem scan)
        root = Path(__file__).resolve().parent.parent
        fallback = root / "wordlists" / "common-small.txt"
        if fallback.is_file():
            wordlist_path = str(fallback)
        else:
            wordlists = list_wordlists()
            if wordlists:
                for w in wordlists:
                    if "common" in w.get("name", "").lower():
                        wordlist_path = w["path"]
                        break
                if not wordlist_path:
                    wordlist_path = wordlists[0]["path"]
        wordlist_suggestion = (
            f"Using wordlist: {wordlist_path}" if wordlist_path else "No SecLists wordlist found. Set SECLISTS_PATH or provide wordlist_path."
        )
    else:
        wordlist_suggestion = f"Using wordlist: {wordlist_path}"

    return {
        "url": url,
        "wordlist_path": wordlist_path,
        "wordlist_suggestion": wordlist_suggestion,
        "next_step": "ask_status_codes",
    }


def ask_status_codes(state: ScanState) -> ScanState:
    """Interrupt: ask user which HTTP status codes to display."""
    default = "200,204,301,302,307,401,403"
    url = state.get("url") or ""
    question = (
        f"Target: {url}\n"
        f"Which HTTP status codes should I display for the gobuster scan?\n"
        f"(e.g. 200,301,403 or press Enter for default: {default})"
    )
    answer = interrupt(question)
    raw = (answer or "").strip() if isinstance(answer, str) else str(answer).strip()
    status_codes = raw if raw else default
    return {
        "status_codes": status_codes,
        "next_step": "run_gobuster",
    }


def run_gobuster_node(state: ScanState) -> ScanState:
    """Run gobuster dir with state url, wordlist_path, status_codes."""
    url = state.get("url") or ""
    wordlist_path = state.get("wordlist_path") or ""
    status_codes = state.get("status_codes") or "200,204,301,302,307,401,403"
    if not url or not wordlist_path:
        return {
            "gobuster_stdout": "",
            "gobuster_stderr": "Missing url or wordlist_path.",
            "gobuster_code": -1,
            "next_step": "end",
        }
    code, stdout, stderr = run_gobuster(
        url=url,
        wordlist_path=wordlist_path,
        status_codes=status_codes,
    )
    return {
        "gobuster_stdout": stdout,
        "gobuster_stderr": stderr,
        "gobuster_code": code,
        "next_step": "ask_run_nuclei",
    }


def ask_run_nuclei(state: ScanState) -> ScanState:
    """Interrupt: ask whether to run Nuclei on the same target."""
    url = (state.get("url") or "").rstrip("/")
    question = (
        f"Gobuster scan completed.\n"
        f"Run Nuclei vulnerability scan on {url}? (yes/no)"
    )
    answer = interrupt(question)
    raw = (answer or "").strip().lower() if isinstance(answer, str) else str(answer).strip().lower()
    run_nuclei_flag = raw in ("yes", "y", "1", "true")
    return {
        "run_nuclei": run_nuclei_flag,
        "next_step": "run_nuclei" if run_nuclei_flag else "end",
    }


def run_nuclei_node(state: ScanState) -> ScanState:
    """Run nuclei on state.url."""
    url = (state.get("url") or "").rstrip("/")
    if not url:
        return {
            "nuclei_stdout": "",
            "nuclei_stderr": "Missing url.",
            "nuclei_code": -1,
            "next_step": "end",
        }
    code, stdout, stderr = run_nuclei(target=url)
    return {
        "nuclei_stdout": stdout,
        "nuclei_stderr": stderr,
        "nuclei_code": code,
        "next_step": "end",
    }


def build_graph():
    builder = StateGraph(ScanState)

    builder.add_node("parse", parse_input)
    builder.add_node("ask_status_codes", ask_status_codes)
    builder.add_node("run_gobuster", run_gobuster_node)
    builder.add_node("ask_run_nuclei", ask_run_nuclei)
    builder.add_node("run_nuclei", run_nuclei_node)

    builder.add_edge(START, "parse")
    builder.add_edge("parse", "ask_status_codes")
    builder.add_edge("ask_status_codes", "run_gobuster")
    builder.add_edge("run_gobuster", "ask_run_nuclei")
    builder.add_conditional_edges(
        "ask_run_nuclei",
        lambda s: "run_nuclei" if s.get("run_nuclei") else "end",
        {"run_nuclei": "run_nuclei", "end": END},
    )
    builder.add_edge("run_nuclei", END)

    memory = MemorySaver()
    return builder.compile(checkpointer=memory)


# Singleton graph for CLI/runner
_graph = None


def get_graph():
    global _graph
    if _graph is None:
        _graph = build_graph()
    return _graph
