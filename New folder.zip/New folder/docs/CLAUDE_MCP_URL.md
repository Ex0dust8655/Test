# Configure MCP URL in Claude

Use these steps to connect Claude to your Security Scan MCP server via URL (HTTP/SSE).

---

## Requirements

- **Claude Pro, Max, Team, or Enterprise** (remote MCP / custom connectors are not available on the free tier).
- Your MCP server running in **HTTP mode** and reachable at a URL (e.g. `http://localhost:8000/sse` or a public URL).

---

## Option 1: Claude on the web (claude.ai)

Claude in the browser can only reach **public URLs**. `localhost` on your PC is not reachable from claude.ai.

### If your server is public (e.g. deployed or ngrok)

1. Open **[claude.ai](https://claude.ai)** and sign in.
2. Go to **Settings** (gear icon) → **Connectors**.
3. In **Connectors**, click **Add custom connector**.
4. Enter your **Remote MCP server URL**:
   - For this project (SSE): use the **SSE endpoint**, e.g.  
     `https://your-domain.com/sse`  
     or with ngrok: `https://abc123.ngrok.io/sse`
5. (Optional) Open **Advanced settings** and set OAuth Client ID / Secret if your server uses OAuth.
6. Click **Add**.

### If your server is only on localhost

Use **Claude Desktop** (Option 2) on the same machine where the server runs; the Desktop app can use `http://localhost:8000/sse`.

---

## Option 2: Claude Desktop (same machine as the server)

When the MCP server runs on the **same computer** as Claude Desktop (e.g. `http://localhost:8000/sse`), you add the connector in the app.

1. Open **Claude Desktop**.
2. Go to **Settings** (gear) → **Connectors**.
3. Click **Add custom connector**.
4. Enter the **Remote MCP server URL**:
   - Local server: `http://localhost:8000/sse`
   - Same machine, different port: `http://127.0.0.1:8000/sse`
5. (Optional) **Advanced settings** → OAuth Client ID / Secret if needed.
6. Click **Add**.

**Important:** Remote MCP servers are **not** configured in `claude_desktop_config.json`. That file is only for **local (stdio)** MCP servers. Use the Connectors UI for any URL-based server.

---

## After adding the connector

1. Start a **new chat** (or open an existing one).
2. Click the **+** (or “Connectors”) in the bottom-left.
3. Turn **on** your “Security Scan” (or whatever you named it) connector.
4. You can then ask Claude to list wordlists, run gobuster, or run nuclei; it will call the MCP tools over the URL.

---

## Quick reference

| Where you use Claude | Server URL you can use |
|----------------------|------------------------|
| **claude.ai** (browser) | Only **public** URLs (e.g. `https://your-server.com/sse` or ngrok). |
| **Claude Desktop** (same PC as server) | `http://localhost:8000/sse` or `http://127.0.0.1:8000/sse`. |

**SSE endpoint for this project:** `http://<host>:8000/sse` (e.g. `http://localhost:8000/sse`).

---

## Exposing localhost for claude.ai (optional)

To use claude.ai with a server that runs on your machine, expose it with a tunnel, e.g.:

- **[ngrok](https://ngrok.com):** `ngrok http 8000` → use the shown `https://...` URL + `/sse` as the MCP URL in Claude.
- Other options: **Cloudflare Tunnel**, **localtunnel**, etc.

Only do this if you’re comfortable exposing the MCP server to the internet; use HTTPS and consider access control.
