# Step-by-Step: Run on Your System

Follow these steps to run the security scan project on your machine, including downloading and using [SecLists](https://github.com/danielmiessler/SecLists) wordlists.

---

## Step 1: Install Prerequisites

### 1.1 Python 3.10+

- **Windows**: Download from [python.org](https://www.python.org/downloads/) or `winget install Python.Python.3.11`
- **macOS**: `brew install python@3.11`
- **Linux**: `sudo apt install python3.11` (or your distro’s package)

Check:

```bash
python --version
```

### 1.2 Go (for Gobuster and Nuclei)

- **Windows**: [golang.org/dl](https://go.dev/dl/) or `winget install GoLang.Go`
- **macOS**: `brew install go`
- **Linux**: `sudo apt install golang-go` or [golang.org/dl](https://go.dev/dl/)

Check:

```bash
go version
```

Ensure `GOPATH/bin` (often `%USERPROFILE%\go\bin` on Windows, `~/go/bin` on macOS/Linux) is in your **PATH**.

---

## Step 2: Download and Store SecLists (Wordlists)

[SecLists](https://github.com/danielmiessler/SecLists) is the security tester’s companion: usernames, passwords, URLs, fuzzing payloads, and wordlists for discovery. We use it for directory/file discovery wordlists (e.g. `Discovery/Web-Content`).

### Option A: Clone into the project (recommended)

From your **project root** (the folder containing `mcp_server`, `agent`, etc.):

**Windows (PowerShell):**

```powershell
cd "C:\New folder"
git clone --depth 1 https://github.com/danielmiessler/SecLists.git
```

**macOS / Linux:**

```bash
cd /path/to/your/project
git clone --depth 1 https://github.com/danielmiessler/SecLists.git
```

This creates a `SecLists` folder inside your project. The project will auto-detect it if you use the path below.

**Set the path (only if you put SecLists somewhere else):**

- **Windows (PowerShell, current session):**  
  `$env:SECLISTS_PATH = "C:\New folder\SecLists"`

- **Windows (permanent):**  
  System Properties → Environment Variables → New User Variable: `SECLISTS_PATH` = `C:\New folder\SecLists`

- **macOS/Linux (current session):**  
  `export SECLISTS_PATH="/path/to/your/project/SecLists"`

- **macOS/Linux (permanent):**  
  Add the line above to `~/.bashrc` or `~/.zshrc`

### Option B: Use the setup script

From the **project root**:

**Windows (PowerShell):**

```powershell
.\scripts\setup_seclists.ps1
```

**macOS / Linux:**

```bash
chmod +x scripts/setup_seclists.sh
./scripts/setup_seclists.sh
```

This clones [SecLists](https://github.com/danielmiessler/SecLists) into `./SecLists` inside your project. The project auto-detects this path; no `SECLISTS_PATH` needed.

---

## Step 3: Install Gobuster and Nuclei

In a terminal:

```bash
# Gobuster (directory/file brute-force)
go install github.com/OJ/gobuster/v3@latest

# Nuclei (vulnerability scanner)
go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest
nuclei -update-templates
```

Check:

```bash
gobuster version
nuclei -version
```

If `gobuster` or `nuclei` is not found, add Go’s bin directory to PATH (see Step 1.2).

---

## Step 4: Install Python Dependencies

From the **project root**:

```bash
cd "C:\New folder"
pip install -r requirements.txt
```

Or with a virtual environment:

```bash
python -m venv .venv
.venv\Scripts\activate   # Windows
# source .venv/bin/activate   # macOS/Linux
pip install -r requirements.txt
```

---

## Step 5: Run the Project

### A. CLI agent (interactive)

From the project root:

```bash
python -m agent.runner "Run gobuster on https://scanme.nmap.org with common.txt"
```

When prompted:

1. **Status codes:** type e.g. `200,301,403` or press Enter for default.
2. **Run Nuclei?** type `yes` or `no`.

Or run without a command-line argument and type your request when asked:

```bash
python -m agent.runner
# Then type: Run gobuster on https://scanme.nmap.org with common.txt
```

### B. Use MCP server from Cursor

1. Open Cursor → **Settings** → **MCP** (or edit `%USERPROFILE%\.cursor\mcp.json` on Windows).
2. Add the server (replace `C:\New folder` with your actual project path):

```json
{
  "mcpServers": {
    "security-scan": {
      "command": "python",
      "args": ["-m", "mcp_server.server"],
      "cwd": "C:\\New folder",
      "env": {}
    }
  }
}
```

3. Restart Cursor (or reload MCP).
4. In chat you can say:
   - “List available SecLists wordlists.”
   - “Run gobuster on https://example.com with [wordlist path]. Show status codes 200,301,403.”
   - “Run nuclei on https://example.com.”

---

## Step 6: Verify SecLists Wordlists

From the project root:

```bash
python -c "from mcp_server.scanner import get_seclists_path, list_wordlists; p=get_seclists_path(); wl=list_wordlists(); print('SecLists path:', p); print('Wordlists count:', len(wl)); print(wl[:3] if wl else 'None')"
```

You should see a path and a list of wordlists (e.g. from `Discovery/Web-Content`). If not, set `SECLISTS_PATH` as in Step 2.

---

## Quick reference

| Step | Action |
|------|--------|
| 1 | Install Python 3.10+ and Go; add Go `bin` to PATH |
| 2 | `git clone --depth 1 https://github.com/danielmiessler/SecLists.git` in project root; set `SECLISTS_PATH` if needed |
| 3 | `go install github.com/OJ/gobuster/v3@latest` and `go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest` then `nuclei -update-templates` |
| 4 | `pip install -r requirements.txt` (from project root) |
| 5 | Run: `python -m agent.runner "Run gobuster on <URL> with common.txt"` or use MCP in Cursor |
| 6 | Verify wordlists with the one-liner above |

---

## Troubleshooting

- **“gobuster not found”**  
  Install Gobuster (Step 3) and add `GOPATH/bin` (e.g. `%USERPROFILE%\go\bin`) to PATH.

- **“nuclei not found”**  
  Same: install Nuclei and add Go’s `bin` to PATH.

- **No wordlists / empty list**  
  Clone SecLists (Step 2) and set `SECLISTS_PATH` to the folder that contains `Discovery/Web-Content`.

- **“No SecLists wordlist found” in agent**  
  Ensure `SECLISTS_PATH` points to the root of the cloned SecLists repo (the folder that contains `Discovery`, `Passwords`, etc.).

Only run scans against targets you are authorized to test.
