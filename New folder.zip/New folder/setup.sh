#!/usr/bin/env bash
# Setup and run Security Scan MCP Server in Docker.
# Optionally host over HTTP so it can be used as a URL (e.g. ChatGPT debug mode).

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR" && pwd)"
IMAGE_NAME="${IMAGE_NAME:-security-scan-mcp}"
CONTAINER_NAME="${CONTAINER_NAME:-security-scan-mcp}"

echo "=== Security Scan MCP - Docker Setup ==="
echo "Project root: $PROJECT_ROOT"
echo ""

# Build image
echo "Building Docker image: $IMAGE_NAME"
docker build -t "$IMAGE_NAME" "$PROJECT_ROOT"
echo ""

# Ask: host over HTTP for URL access (ChatGPT debug mode)?
echo "Host the MCP server over HTTP so it can be used as a URL?"
echo "  - Yes: Server will listen on 0.0.0.0:8000 (or chosen port)."
echo "         You can connect ChatGPT / MCP Inspector via http://localhost:8000/sse"
echo "  - No:  Server runs in stdio mode (for Cursor / local MCP clients)."
echo ""
read -r -p "Host over HTTP for URL access? [y/N]: " USE_HTTP
USE_HTTP="${USE_HTTP:-n}"

PORT="${PORT:-8000}"

if [[ "$USE_HTTP" =~ ^[yY] ]]; then
  echo ""
  read -r -p "Port to expose [8000]: " INPUT_PORT
  PORT="${INPUT_PORT:-8000}"
  echo ""
  echo "Starting container with HTTP/SSE transport on port $PORT..."
  echo "  - SSE endpoint:  http://localhost:$PORT/sse"
  echo "  - Messages:      http://localhost:$PORT/messages/"
  echo ""
  echo "To connect ChatGPT (debug mode) or MCP Inspector:"
  echo "  URL: http://localhost:$PORT/sse"
  echo "  (or http://<your-host-ip>:$PORT/sse if accessing from another machine)"
  echo ""

  # Stop existing container if same name
  docker rm -f "$CONTAINER_NAME" 2>/dev/null || true

  docker run -d \
    --name "$CONTAINER_NAME" \
    -p "$PORT:8000" \
    -v "$PROJECT_ROOT/SecLists:/app/SecLists:ro" \
    "$IMAGE_NAME" \
    python -m mcp_server.server --transport sse --port 8000 --host 0.0.0.0

  echo "Container started: $CONTAINER_NAME"
  echo "Logs: docker logs -f $CONTAINER_NAME"
  echo "Stop: docker stop $CONTAINER_NAME"
else
  echo "Skipping container start (stdio mode is for Cursor when it launches the server)."
  echo ""
  echo "To use with Cursor, set your MCP server command to:"
  echo "  docker run -i --rm -v \"$PROJECT_ROOT/SecLists:/app/SecLists:ro\" $IMAGE_NAME"
  echo ""
  echo "Or run the server directly in the container (stdio):"
  echo "  docker run -i --rm -v \"$PROJECT_ROOT/SecLists:/app/SecLists:ro\" $IMAGE_NAME"
fi

echo ""
echo "Done."
