# Security Scan MCP Server - Nuclei, Gobuster, SecLists
