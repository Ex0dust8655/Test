"""
Security Scan MCP Server - exposes Nuclei, Gobuster, SecLists as MCP tools.
Run: python -m mcp_server.server
  Or with HTTP (for URL access / ChatGPT): python -m mcp_server.server --transport sse --port 8000 --host 0.0.0.0
"""
import argparse
import json
from pathlib import Path

import anyio
from mcp.server.lowlevel import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

from mcp_server.scanner import (
    get_seclists_path,
    list_wordlists,
    run_gobuster,
    run_nuclei,
)

app = Server("security-scan-mcp")


@app.list_tools()
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name="list_wordlists",
            description="List available SecLists wordlists (Discovery/Web-Content). Set SECLISTS_PATH env if SecLists is elsewhere.",
            inputSchema={"type": "object", "properties": {}},
        ),
        Tool(
            name="run_gobuster",
            description="Run gobuster dir scan on a URL with a wordlist. Specify status codes to display (e.g. 200,301,403).",
            inputSchema={
                "type": "object",
                "required": ["url", "wordlist_path"],
                "properties": {
                    "url": {"type": "string", "description": "Target base URL (e.g. https://example.com/)"},
                    "wordlist_path": {"type": "string", "description": "Full path to wordlist file (e.g. from list_wordlists)"},
                    "status_codes": {
                        "type": "string",
                        "description": "Comma-separated HTTP status codes to show (default: 200,204,301,302,307,401,403)",
                        "default": "200,204,301,302,307,401,403",
                    },
                    "threads": {"type": "integer", "description": "Number of threads", "default": 10},
                    "timeout_sec": {"type": "integer", "description": "Request timeout in seconds", "default": 10},
                    "extensions": {"type": "string", "description": "File extensions to try e.g. php,html"},
                    "out_file": {"type": "string", "description": "Save results to file"},
                },
            },
        ),
        Tool(
            name="run_nuclei",
            description="Run Nuclei vulnerability scan on a target URL.",
            inputSchema={
                "type": "object",
                "required": ["target"],
                "properties": {
                    "target": {"type": "string", "description": "Target URL to scan"},
                    "templates": {"type": "string", "description": "Path or comma-separated template paths"},
                    "severity": {"type": "string", "description": "Filter by severity: critical,high,medium,low,info"},
                    "concurrency": {"type": "integer", "description": "Concurrency", "default": 25},
                    "out_file": {"type": "string", "description": "Save results to file"},
                },
            },
        ),
    ]


@app.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    if name == "list_wordlists":
        base = arguments.get("base_path")
        path = Path(base) if base else None
        items = list_wordlists(path)
        if not items:
            seclists = get_seclists_path()
            msg = "No wordlists found. Set SECLISTS_PATH to your SecLists directory (e.g. clone https://github.com/danielmiessler/SecLists)."
            if seclists:
                msg = f"SecLists path: {seclists}. No files in Discovery/Web-Content."
            return [TextContent(type="text", text=msg)]
        return [TextContent(type="text", text=json.dumps(items, indent=2))]

    if name == "run_gobuster":
        url = arguments.get("url") or ""
        wordlist_path = arguments.get("wordlist_path") or ""
        status_codes = arguments.get("status_codes") or "200,204,301,302,307,401,403"
        threads = int(arguments.get("threads") or 10)
        timeout_sec = int(arguments.get("timeout_sec") or 10)
        extensions = arguments.get("extensions")
        out_file = arguments.get("out_file")
        code, stdout, stderr = run_gobuster(
            url=url,
            wordlist_path=wordlist_path,
            status_codes=status_codes,
            threads=threads,
            timeout_sec=timeout_sec,
            extensions=extensions,
            out_file=out_file,
        )
        text = f"returncode: {code}\nstdout:\n{stdout}\nstderr:\n{stderr}"
        return [TextContent(type="text", text=text)]

    if name == "run_nuclei":
        target = arguments.get("target") or ""
        templates = arguments.get("templates")
        severity = arguments.get("severity")
        concurrency = int(arguments.get("concurrency") or 25)
        out_file = arguments.get("out_file")
        code, stdout, stderr = run_nuclei(
            target=target,
            templates=templates,
            severity=severity,
            concurrency=concurrency,
            out_file=out_file,
        )
        text = f"returncode: {code}\nstdout:\n{stdout}\nstderr:\n{stderr}"
        return [TextContent(type="text", text=text)]

    return [TextContent(type="text", text=f"Unknown tool: {name}")]


async def run_stdio():
    async with stdio_server() as streams:
        await app.run(streams[0], streams[1], app.create_initialization_options())


def run_sse(host: str, port: int):
    from mcp.server.sse import SseServerTransport
    from starlette.applications import Starlette
    from starlette.responses import Response
    from starlette.routing import Mount, Route
    import uvicorn

    sse = SseServerTransport("/messages/")

    async def handle_sse(request):
        async with sse.connect_sse(request.scope, request.receive, request._send) as streams:
            await app.run(streams[0], streams[1], app.create_initialization_options())
        return Response()

    starlette_app = Starlette(
        debug=False,
        routes=[
            Route("/sse", endpoint=handle_sse, methods=["GET"]),
            Mount("/messages/", app=sse.handle_post_message),
        ],
    )
    uvicorn.run(starlette_app, host=host, port=port)


def main():
    parser = argparse.ArgumentParser(description="Security Scan MCP Server")
    parser.add_argument(
        "--transport",
        choices=["stdio", "sse"],
        default="stdio",
        help="stdio for Cursor/local; sse for HTTP URL (e.g. ChatGPT debug mode)",
    )
    parser.add_argument("--port", type=int, default=8000, help="Port when using --transport sse")
    parser.add_argument("--host", default="0.0.0.0", help="Host when using --transport sse (0.0.0.0 for all interfaces)")
    args = parser.parse_args()

    if args.transport == "sse":
        run_sse(args.host, args.port)
    else:
        anyio.run(run_stdio)


if __name__ == "__main__":
    main()
