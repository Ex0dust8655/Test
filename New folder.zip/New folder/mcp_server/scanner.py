"""
Shared scanner logic: Gobuster, Nuclei, SecLists.
Used by both MCP server and LangGraph agent.
"""
import os
import subprocess
from pathlib import Path
from typing import Optional

# Caches to avoid repeated filesystem work (faster MCP/list responses)
_seclists_path_cache: Optional[Path] = None
_wordlist_cache: Optional[list[dict]] = None
_wordlist_cache_root: Optional[Path] = None


def _project_root() -> Path:
    """Project root (parent of mcp_server)."""
    return Path(__file__).resolve().parent.parent


def _wordlists_dir() -> Path:
    """Project wordlists folder (for custom/small wordlists)."""
    return _project_root() / "wordlists"


# Default SecLists path (common locations); project SecLists checked first
def _seclists_defaults() -> list[Path]:
    root = _project_root()
    return [
        root / "SecLists",              # Clone inside project (recommended)
        Path("/usr/share/seclists"),    # Kali / Debian
        Path("C:\\New folder\\wordlists\\SecLists"),            # Windows
        Path(os.path.expanduser("~/SecLists")),
        Path(os.path.expanduser("~/tools/SecLists")),
    ]


def get_seclists_path() -> Optional[Path]:
    """Resolve SecLists directory from env or defaults (cached)."""
    global _seclists_path_cache
    if _seclists_path_cache is not None:
        return _seclists_path_cache
    path = os.environ.get("SECLISTS_PATH")
    if path and Path(path).is_dir():
        _seclists_path_cache = Path(path)
        return _seclists_path_cache
    for p in _seclists_defaults():
        if p.is_dir():
            _seclists_path_cache = p
            return _seclists_path_cache
    return None


def list_wordlists(base: Optional[Path] = None, use_cache: bool = True) -> list[dict]:
    """
    List available wordlists (cached for speed). Checks project wordlists/ first, then SecLists.
    Returns list of {path, name, size}; max 30 entries for fast response.
    """
    global _wordlist_cache, _wordlist_cache_root
    root = base or get_seclists_path()
    if use_cache and _wordlist_cache is not None and _wordlist_cache_root == root:
        return _wordlist_cache

    out: list[dict] = []
    # 1) Project wordlists/ (fast, small)
    wd = _wordlists_dir()
    if wd.is_dir():
        for f in sorted(wd.iterdir())[:20]:
            if f.is_file():
                out.append({"path": str(f), "name": f.name, "size": f.stat().st_size})

    # 2) SecLists Discovery/Web-Content
    if root and root.is_dir():
        web_content = root / "Discovery" / "Web-Content"
        if web_content.is_dir():
            for f in sorted(web_content.iterdir())[:25]:
                if f.is_file():
                    out.append({"path": str(f), "name": f.name, "size": f.stat().st_size})
        for rel in ["common.txt", "raft-small-directories.txt", "directory-list-2.3-small.txt"]:
            p = root / "Discovery" / "Web-Content" / rel
            if p.is_file() and not any(x["path"] == str(p) for x in out):
                out.append({"path": str(p), "name": p.name, "size": p.stat().st_size})

    out = out[:30]
    if use_cache:
        _wordlist_cache = out
        _wordlist_cache_root = root
    return out


def run_gobuster(
    url: str,
    wordlist_path: str,
    status_codes: str = "200,204,301,302,307,401,403",
    threads: int = 10,
    timeout_sec: int = 10,
    extensions: Optional[str] = None,
    out_file: Optional[str] = None,
) -> tuple[int, str, str]:
    """
    Run gobuster dir. Returns (returncode, stdout, stderr).
    """
    if not url.endswith("/"):
        url = url.rstrip() + "/"
    cmd = [
        "gobuster", "dir",
        "-u", url,
        "-w", wordlist_path,
        "-s", status_codes,
        "-t", str(threads),
        "--timeout", f"{timeout_sec}s",
        "-q",
    ]
    if extensions:
        cmd.extend(["-x", extensions])
    if out_file:
        cmd.extend(["-o", out_file])
    try:
        r = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=300,
        )
        return r.returncode, r.stdout or "", r.stderr or ""
    except FileNotFoundError:
        return -1, "", "gobuster not found. Install: go install github.com/OJ/gobuster/v3@latest"
    except subprocess.TimeoutExpired:
        return -1, "", "gobuster timed out after 300s"


def run_nuclei(
    target: str,
    templates: Optional[str] = None,
    severity: Optional[str] = None,
    concurrency: int = 25,
    out_file: Optional[str] = None,
) -> tuple[int, str, str]:
    """
    Run nuclei on target (URL or file path with -l).
    Returns (returncode, stdout, stderr).
    """
    cmd = ["nuclei", "-u", target, "-c", str(concurrency)]
    if templates:
        cmd.extend(["-t", templates])
    if severity:
        cmd.extend(["-severity", severity])
    if out_file:
        cmd.extend(["-o", out_file])
    try:
        r = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=1800,
        )
        return r.returncode, r.stdout or "", r.stderr or ""
    except FileNotFoundError:
        return -1, "", "nuclei not found. Install: go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest"
    except subprocess.TimeoutExpired:
        return -1, "", "nuclei timed out after 1800s"
