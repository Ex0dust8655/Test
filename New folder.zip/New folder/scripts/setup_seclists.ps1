# Clone SecLists into the project folder for wordlists
# Run from project root: .\scripts\setup_seclists.ps1

# When run from project root: .\scripts\setup_seclists.ps1 -> $PSScriptRoot = ...\scripts
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$SecListsPath = Join-Path $ProjectRoot "SecLists"

if (Test-Path $SecListsPath) {
    Write-Host "SecLists already exists at: $SecListsPath"
    Write-Host "To re-download, remove the folder and run this script again."
    exit 0
}

Write-Host "Cloning SecLists (shallow) into: $SecListsPath"
Write-Host "Source: https://github.com/danielmiessler/SecLists"
Write-Host ""

Set-Location $ProjectRoot
git clone --depth 1 https://github.com/danielmiessler/SecLists.git

if (Test-Path $SecListsPath) {
    Write-Host ""
    Write-Host "Done. SecLists is at: $SecListsPath"
    Write-Host "The project will auto-detect this path (no SECLISTS_PATH needed)."
    Write-Host "To set env var anyway (e.g. for another shell):"
    Write-Host "  `$env:SECLISTS_PATH = `"$SecListsPath`""
} else {
    Write-Host "Clone failed. Ensure git is installed and you have network access."
    exit 1
}
