#!/usr/bin/env bash
# Clone SecLists into the project folder for wordlists
# Run from project root: ./scripts/setup_seclists.sh

set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
SECLISTS_PATH="$PROJECT_ROOT/SecLists"

if [ -d "$SECLISTS_PATH" ]; then
    echo "SecLists already exists at: $SECLISTS_PATH"
    echo "To re-download, remove the folder and run this script again."
    exit 0
fi

echo "Cloning SecLists (shallow) into: $SECLISTS_PATH"
echo "Source: https://github.com/danielmiessler/SecLists"
echo ""

cd "$PROJECT_ROOT"
git clone --depth 1 https://github.com/danielmiessler/SecLists.git

echo ""
echo "Done. SecLists is at: $SECLISTS_PATH"
echo "The project will auto-detect this path (no SECLISTS_PATH needed)."
echo "To set env var anyway: export SECLISTS_PATH=\"$SECLISTS_PATH\""
