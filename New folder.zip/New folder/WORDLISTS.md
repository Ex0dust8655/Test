# Where to Store Wordlist Files

Use **one** of these locations so the MCP server and agent find your wordlists quickly.

---

## Recommended locations (in order)

### 1. **Project `wordlists/` folder** (fastest, for custom/small lists)

**Path:** `<project_root>/wordlists/`

- **Example:** `c:\New folder\wordlists\` (Windows) or `/path/to/project/wordlists/` (Linux/macOS)
- Put your `.txt` wordlist files here (e.g. `common-small.txt`, `custom-dirs.txt`).
- The app checks this **first** (cached), so responses stay fast.
- Use this for small or custom wordlists you create.

**Example:**
```
c:\New folder\
  wordlists\
    common-small.txt
    custom-dirs.txt
    api-paths.txt
```

---

### 2. **SecLists (full repo)** (for standard SecLists wordlists)

**Path:** `<project_root>/SecLists` **or** set `SECLISTS_PATH`

- **Option A – Inside project:** Clone [SecLists](https://github.com/danielmiessler/SecLists) into the project:
  ```bash
  cd "c:\New folder"
  git clone --depth 1 https://github.com/danielmiessler/SecLists.git
  ```
  Then wordlists live at: `c:\New folder\SecLists\Discovery\Web-Content\` (e.g. `common.txt`).

- **Option B – Anywhere else:** Clone SecLists to a folder and set the env var:
  - **Windows:** `set SECLISTS_PATH=C:\path\to\SecLists`
  - **Linux/macOS:** `export SECLISTS_PATH=/path/to/SecLists`
  The app will use `SECLISTS_PATH/Discovery/Web-Content/` for directory wordlists.

- Listing is **cached** after the first call, so later responses are fast.

---

## Summary

| Use case | Where to store |
|----------|----------------|
| **Custom / small wordlists** | `wordlists/` inside the project |
| **Full SecLists repo** | `SecLists/` inside the project, or any path in `SECLISTS_PATH` |

**Best practice:** Keep small/custom lists in **`wordlists/`**; use **SecLists** when you need the full SecLists set (e.g. `common.txt`, `raft-small-directories.txt`).
